if(typeof exports === 'object') {
	var assert = require("assert");
	var alasql = require('..');
};

describe('Test 83 - MDX SELECT', function() {


//	it.skip('localStorage', function(done){
//		done();
//	});

});
