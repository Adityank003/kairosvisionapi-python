if(typeof exports === 'object') {
	var assert = require("assert");
	var alasql = require('..');
};

describe('Test 65 - Cursors', function() {


	it.skip('CURSOR', function(done){
		done();
	});

});
