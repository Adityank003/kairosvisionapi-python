if(alasql.options.postgres) {
}