if(alasql.options.oracle) {
}