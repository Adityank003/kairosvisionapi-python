if(alasql.options.sqlite) {
}