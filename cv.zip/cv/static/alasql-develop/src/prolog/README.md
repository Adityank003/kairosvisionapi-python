# Prolog queries

:-
?-
