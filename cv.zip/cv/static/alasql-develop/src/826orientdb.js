if(alasql.options.orientdb) {
}