from django.apps import AppConfig


class MlConfig(AppConfig):
    name = 'ml'
